import UIKit

//------------ Ejercicio 1

class Perro{
    var name: String
    var color: String
    var age: Int
    
    init(nombre: String, color:String, edad: Int){
        self.name = nombre
        self.color = color
        self.age = edad
    }
}

class Persona{
    var name: String
    var identifier: String
    var age: Int
    var perros: [Perro]
    
    init(nombre: String, id: String, edad: Int){
        self.name = nombre
        self.identifier = id
        self.age = edad
        perros = [Perro]()
    }
}

//------------ Ejercicio 2
func crearPersonas(){
    let p1 : Persona = Persona(nombre: "Sebastian", id: "101110111", edad: 83)
    let d1p1: Perro = Perro(nombre: "Gorda", color: "Beige", edad: 9)
    let d2p1: Perro = Perro(nombre: "Oso", color: "Negro", edad: 8)
    p1.perros.append(d1p1)
    p1.perros.append(d2p1)
    
    let p2 : Persona = Persona(nombre: "Maripaz", id: "202220222", edad: 8)
    let d1p2: Perro = Perro(nombre: "Holy", color: "Cafe", edad: 8)
    let d2p2: Perro = Perro(nombre: "Tribilin", color: "Gris", edad: 11)
    p2.perros.append(d1p2)
    p2.perros.append(d2p2)
    
    //Arreglo para imprimir en ciclo
    let personas = [p1, p2]
    var idPerro: Int;
    
    for p in personas {
        idPerro = 1
        print("Nombre: \(p.name)")
        print("Identificador: \(p.identifier)")
        print("Edad \(p.age)")
        print("Cantidad de perros \(p.perros.count)")
        
        
        for d in p.perros{
            print("\tPerro \(idPerro)")
            print("\t\tNombre \(d.name)")
            print("\t\tColor \(d.color)")
            print("\t\tEdad \(d.age)")
        
            idPerro += 1
        }
        
        print("\n")
    }
}

crearPersonas()


//------------ Ejercicio 3
func obtenerPrimos(numFinal: Int) -> [Int]{
    var resultado = [Int]()
    
    for idx in 1...numFinal{
        var primo = true
        
        if (idx > 1){
            for idx2 in 2..<idx{
                if (idx % idx2 == 0){
                    primo = false
                    break
                }
            }
        }
        
        if primo{
            resultado.append(idx)
        }
    }
    
    return resultado
}

let primos = obtenerPrimos(numFinal: 13)


//------------ Ejercicio 4
func unirYOrdenar(arreglo1: [Int], arreglo2: [Int]){
    var unido = arreglo1 + arreglo2
    
    unido.sort(by: {$0 < $1})
    
    var impresionArreglo = ""
    
    for val in unido {
        if (impresionArreglo != ""){
            impresionArreglo += ", "
        }
        impresionArreglo += "\(val) "
    }
    
    print (impresionArreglo)
}

var arr1 = [5,2,7,6]
var arr2 = [9,1,4,8]

unirYOrdenar(arreglo1: arr1, arreglo2: arr2)
