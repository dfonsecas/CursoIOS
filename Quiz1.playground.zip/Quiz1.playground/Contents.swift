import UIKit

func esSumatoriaPar(arreglo: [Int]) -> Bool{
    var sumaPar = 0
    var sumaImpar = 0
    
    for valor in arreglo{
        if (valor % 2 == 0){
            sumaPar += valor
        }else{
            sumaImpar += valor
        }
    }
    
    if (sumaPar > sumaImpar){
        return true
    }else{
        return false
    }
}

func divisoresNum (numero : Int) -> [Int]{
    var divisores = [Int]()
    
    for posibleDivisor in 1 ..< numero{
        if (numero % posibleDivisor == 0){
            divisores.append(posibleDivisor)
        }
    }
    
    return divisores
}

func promedio (numeros : [Float]) -> Float{
    var sumatoria : Float = 0
    
    for valor in numeros{
        sumatoria += valor
    }
    
    return sumatoria / Float(numeros.count)
}

//Pruebas
var arregloSumatoria = [2, 3, 4, 5, 6, 7]
esSumatoriaPar(arreglo: arregloSumatoria)


