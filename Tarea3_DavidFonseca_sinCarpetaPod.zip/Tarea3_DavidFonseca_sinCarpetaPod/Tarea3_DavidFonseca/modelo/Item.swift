//
//  Item.swift
//  Tarea3_DavidFonseca
//
//  Created by dafons on 2/21/19.
//  Copyright © 2019 dafons. All rights reserved.
//

import Foundation
import RealmSwift

// Define your models like regular Swift classes
class Item: Object {
    @objc dynamic var fecha = Date()
    @objc dynamic var titulo = ""
    @objc dynamic var id = UUID().uuidString
    
    //Se establece la llave primaria
    override static func primaryKey() -> String?{
        return "id"
    }
    
    override static func indexedProperties() -> [String]{
        return ["titulo"]
    }
    
}
