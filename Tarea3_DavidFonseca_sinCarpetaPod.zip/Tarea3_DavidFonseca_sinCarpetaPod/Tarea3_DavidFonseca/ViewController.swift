//
//  ViewController.swift
//  Tarea3_DavidFonseca
//
//  Created by dafons on 2/21/19.
//  Copyright © 2019 dafons. All rights reserved.
//

import UIKit
import RealmSwift

class ViewController: UIViewController {

    @IBOutlet weak var textfield: UITextField!
    
    @IBOutlet weak var tabla: UITableView!
    
    var articulos: Results<Item>? = nil
    
    let formatoFecha = DateFormatter()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        formatoFecha.dateFormat = "dd-MM-yyyy HH:mm:ss"
        
        actualizarListaArticulos()
        
        registerCustomCell()
    }
    
    @IBAction func btnAgregar(_ sender: Any) {
        let alert = UIAlertController(title: "Nuevo Articulo", message: "Ingrese el nuevo articulo.", preferredStyle: UIAlertController.Style.alert)
        
        alert.addTextField(configurationHandler: { (textField) in
            textField.placeholder = "Nombre del articulo"
        })
        
        alert.addAction(UIAlertAction(title: "Guardar", style: UIAlertAction.Style.default, handler:{ (UIAlertAction)in
            
            let item = Item()
            item.fecha = Date()
            item.titulo = alert.textFields?[0].text ?? "Sin datos"
            
            self.guardarArticulos(articulo: item)
        }))
        
        alert.addAction(UIAlertAction(title: "Cerrar", style: UIAlertAction.Style.cancel, handler:{ (UIAlertAction)in
        }))
        
        self.present(alert, animated: true, completion: nil)
    }
    
    private func actualizarListaArticulos(){
        do{
            let realm = try Realm()
        
            self.articulos = realm.objects(Item.self)
            
            tabla.reloadData()
        }catch{
            
        }
    }
    
    private func guardarArticulos(articulo: Object){
        do{
            let realm = try Realm()
            try realm.write {
                realm.add(articulo, update: true)
                
                self.actualizarListaArticulos()
            }
        }catch let error as NSError {
            print("Error guardando \(error)")
        }
    }
    
    private func eliminarArticulos(articulo: Object){
        do{
            let realm = try Realm()
            try realm.write {
                realm.delete(articulo)
            }
        }catch let error as NSError {
            print("Error eliminando \(error)")
        }
    }
}

extension ViewController: UITableViewDelegate, UITableViewDataSource{
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        if self.articulos == nil{
            return 0
        }else{
            return self.articulos?.count ?? 0
        }
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        guard let cell = tableView.dequeueReusableCell(withIdentifier: "ArticulosTableViewCell") as? ArticulosTableViewCell else {
            return UITableViewCell()
        }
        
        if let articulos = articulos {
            let articulo = articulos[indexPath.row]
            cell.lblFecha.text = formatoFecha.string(from: articulo.fecha)
            cell.lblArticulo.text = articulo.titulo
        }
        
        return cell
    }
    
    private func registerCustomCell() {
        let nib = UINib(nibName: "ArticulosTableViewCell", bundle: nil)
        tabla.register(nib, forCellReuseIdentifier: "ArticulosTableViewCell")
    }
    
    // Metodo para borrar la celda
    func tableView(_ tableView: UITableView, commit editingStyle: UITableViewCell.EditingStyle, forRowAt indexPath: IndexPath) {
        
        if editingStyle == .delete {
            //Borra de la BD
            self.eliminarArticulos(articulo: (self.articulos?[indexPath.row])!)
           
            // Borra de la vista
            tableView.deleteRows(at: [indexPath], with: .fade)
            
        } else if editingStyle == .insert {
            //No se hace nada si falla la eliminacion
        }
    }
}
