//
//  ArticulosTableViewCell.swift
//  Tarea3_DavidFonseca
//
//  Created by dafons on 2/21/19.
//  Copyright © 2019 dafons. All rights reserved.
//

import UIKit

class ArticulosTableViewCell: UITableViewCell {

    @IBOutlet weak var lblFecha: UILabel!
    
    @IBOutlet weak var lblArticulo: UILabel!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }
    
}
