//
//  CeldaCustomTableViewCell.swift
//  Tarea2_DavidFonseca
//
//  Created by ice on 8/2/19.
//  Copyright © 2019 personal. All rights reserved.
//

import UIKit

class CeldaCustomTableViewCell: UITableViewCell {

    @IBOutlet weak var view: UIView!
    
    @IBOutlet weak var stack: UIStackView!
    
    @IBOutlet weak var etiqueta: UILabel!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }
    
}
