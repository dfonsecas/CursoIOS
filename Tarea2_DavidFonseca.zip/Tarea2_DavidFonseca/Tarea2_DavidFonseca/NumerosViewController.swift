//
//  NumerosViewController.swift
//  Tarea2_DavidFonseca
//
//  Created by ice on 8/2/19.
//  Copyright © 2019 personal. All rights reserved.
//

import UIKit

class NumerosViewController: UIViewController {
    var datos = [Int]();
    
    @IBOutlet weak var tabla: UITableView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        for i in 1000 ..< 2000{
            datos.append(i)
        }
        
        registerCustomTableView()
    }
    
    func registerCustomTableView(){
        let nib = UINib(nibName: "CeldaCustomTableViewCell", bundle: nil)
        tabla.register(nib, forCellReuseIdentifier: "CeldaCustomTableViewCell")
    }
}

extension NumerosViewController : UITableViewDelegate, UITableViewDataSource{
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return datos.count;
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        guard let celda = tableView.dequeueReusableCell(withIdentifier: "CeldaCustomTableViewCell") as? CeldaCustomTableViewCell else {
            return UITableViewCell()
        }
        
        celda.etiqueta.text = String(datos[indexPath.row])
        
        if (datos[indexPath.row] % 2 == 0){
            celda.view.layer.backgroundColor = UIColor.blue.cgColor
        }else{
            celda.view.layer.backgroundColor = UIColor.red.cgColor
        }
        
        return celda
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 150.0 //Altura de la celda
    }
    
    func numberOfSections(in tableView: UITableView) -> Int {
        return 1
    }
}
