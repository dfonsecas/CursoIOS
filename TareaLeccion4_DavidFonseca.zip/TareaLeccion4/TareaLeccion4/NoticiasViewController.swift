//
//  NoticiasViewController.swift
//  TareaLeccion4
//
//  Created by ice on 5/2/19.
//  Copyright © 2019 personal. All rights reserved.
//

import UIKit

class NoticiasViewController: UIViewController {
    @IBOutlet weak var lblTitulo: UILabel!
    
    @IBOutlet weak var tabla: UITableView!
    
    @IBOutlet weak var imgCategoria: UIImageView!
    
    var categoria : Categoria = Categoria(nombre: "", imagen: "")

    let df = DateFormatter()
    
    override func viewDidLoad() {
        super.viewDidLoad()

        lblTitulo.text = categoria.nombre
        
        let img: UIImage = UIImage(named: categoria.imagen)!
        
        imgCategoria.image = img
        
        df.dateFormat = "dd/MM/yyyy hh:mm:ss"
        
        registerCustomTableView()
    }
    
    @IBAction func addNoticiaAction(_ sender: Any) {
        let storyboard : UIStoryboard = UIStoryboard(name: "Main", bundle: nil)
        
        let vc : AgregarNoticiaViewController = storyboard.instantiateViewController(withIdentifier: "AgregarNoticiaViewController") as! AgregarNoticiaViewController
        
        vc.delegate = self
        
        self.present(vc, animated: true, completion: nil)
    }
    
    func registerCustomTableView(){
        let nib = UINib(nibName: "NoticiaTableViewCell", bundle: nil)
        tabla.register(nib, forCellReuseIdentifier: "NoticiaTableViewCell")
    }
}

extension NoticiasViewController: AgregarNoticiaViewControllerDelegate {
    func publicarNoticia(noticia: Noticia) {
        dismiss(animated: true, completion: nil)
        categoria.noticias.append(noticia)
        
        print("Llega la noticia \(noticia.titulo)")
        
        tabla.reloadData()
    }
}

extension NoticiasViewController: UITableViewDelegate, UITableViewDataSource{
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return categoria.noticias.count;
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        //Se identifica como el nobre de la clase y se castea al tipo custom con el as?
        guard let celda = tableView.dequeueReusableCell(withIdentifier: "NoticiaTableViewCell") as? NoticiaTableViewCell else {
            return UITableViewCell()
        }
        
        print("++++++ \(categoria.noticias[indexPath.row].titulo)")
        
        celda.titulo.text = categoria.noticias[indexPath.row].titulo
        celda.fecha.text = self.df.string(from: categoria.noticias[indexPath.row].creacion)
        celda.cuerpo.text = categoria.noticias[indexPath.row].cuerpo
        
        return celda
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 80.0 //Altura de la celda
    }
    
    func numberOfSections(in tableView: UITableView) -> Int {
        return 1
    }
    
    // Metodo para borrar la celda
    func tableView(_ tableView: UITableView, commit editingStyle: UITableViewCell.EditingStyle, forRowAt indexPath: IndexPath) {
        
        if editingStyle == .delete {
            //Borra del modelo
            categoria.noticias.remove(at: indexPath.row)
            
            // Borra de la vista
            tableView.deleteRows(at: [indexPath], with: .fade)
            
        } else if editingStyle == .insert {
            //No se hace nada si falla la eliminacion
        }
    }
}
