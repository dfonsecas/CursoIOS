//
//  CategoriasTableViewCell.swift
//  TareaLeccion4
//
//  Created by ice on 5/2/19.
//  Copyright © 2019 personal. All rights reserved.
//

import UIKit

class CategoriasTableViewCell: UITableViewCell {

    @IBOutlet weak var etiqueta: UILabel!
    @IBOutlet weak var imagen: UIImageView!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }
    
}
