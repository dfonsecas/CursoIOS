//
//  Cat.swift
//  Quiz2
//
//  Created by dafons on 2/23/19.
//  Copyright © 2019 dafons. All rights reserved.
//

import Foundation
import RealmSwift

// Define your models like regular Swift classes
class Cat: Object {
    @objc dynamic var name = ""
    @objc dynamic var order = 0
    @objc dynamic var color = ""
    

    
    //Se establece la llave primaria
    override static func primaryKey() -> String?{
        return "name"
    }
    
    override static func indexedProperties() -> [String]{
        return ["name"]
    }
    
}
