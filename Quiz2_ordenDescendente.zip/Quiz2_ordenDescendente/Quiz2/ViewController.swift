//
//  ViewController.swift
//  Quiz2
//
//  Created by dafons on 2/23/19.
//  Copyright © 2019 dafons. All rights reserved.
//

import UIKit
import RealmSwift

class ViewController: UIViewController {

    @IBOutlet weak var tabla: UITableView!
    
    var cats: Results<Cat>? = nil
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        getCatsList()
        
        registerCustomCell()
        // Do any additional setup after loading the view, typically from a nib.
    }

    private func getCatsList(){
        do{
            let realm = try Realm()
            
            self.cats = realm.objects(Cat.self).sorted(byKeyPath: "order", ascending: false)
            
            if (self.cats?.count == 0){
                createCats()
            }
            
            tabla.reloadData()
        }catch{
            
        }
    }
    
    private func createCats(){
        let c0 = Cat.init(value:["name": "Gato 10", "order": 10, "color": "Blanco"])
        let c1 = Cat.init(value:["name": "Gato 4", "order": 4, "color": "Negro"])
        let c2 = Cat.init(value:["name": "Gato 7", "order": 7, "color": "Cafe"])
        let c3 = Cat.init(value:["name": "Gato 1", "order": 1, "color": "Manchas"])
        let c4 = Cat.init(value:["name": "Gato 3", "order": 3, "color": "Gris"])
        let c5 = Cat.init(value:["name": "Gato 8", "order": 8, "color": "Beige"])
        let c6 = Cat.init(value:["name": "Gato 2", "order": 2, "color": "Blanco"])
        let c7 = Cat.init(value:["name": "Gato 9", "order": 9, "color": "Ceniza"])
        let c8 = Cat.init(value:["name": "Gato 6", "order": 6, "color": "Gris"])
        let c9 = Cat.init(value:["name": "Gato 5", "order": 5, "color": "Negro"])
        
        let arrayInsert = [c0, c1, c2, c3, c4, c5, c6, c7, c8, c9]
        
        for cat in arrayInsert{
            guardarGato(cat: cat)
        }
    }
    
    private func guardarGato(cat: Cat){
        do{
            let realm = try Realm()
            try realm.write {
                realm.add(cat, update: true)
            }
        }catch let error as NSError {
            print("Error guardando \(error)")
        }
    }
}

extension ViewController: UITableViewDelegate, UITableViewDataSource{
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        if self.cats == nil{
            return 0
        }else{
            return self.cats?.count ?? 0
        }
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        guard let cell = tableView.dequeueReusableCell(withIdentifier: "CatTableViewCell") as? CatTableViewCell else {
            return UITableViewCell()
        }
        
        if let cats = cats {
            let cat = cats[indexPath.row]
            cell.label.text = cat.name
        }
        
        return cell
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 80.0
    }
    
    private func registerCustomCell() {
        let nib = UINib(nibName: "CatTableViewCell", bundle: nil)
        tabla.register(nib, forCellReuseIdentifier: "CatTableViewCell")
    }
}
